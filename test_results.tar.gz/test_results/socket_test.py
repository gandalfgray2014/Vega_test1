#!/usr/bin/python

import websocket
import random
import time

url1="ws://192.168.17.128/echo"
N=100
M=100

ws = websocket.create_connection(url1)
random.random()

t1=time.time()
count=1
while count<=M:
  a=random.uniform(1,10)
  ws.send(str(a))
  count += 1
ws.close()
t2=time.time()
print("We have tested %d requests to socket. It takes %f seconds" % (M,t2-t1))

t1=time.time()
while count<=N:
  ws = websocket.create_connection(url1)
  ws.close()
  count +=1
t2=time.time()
print("We have tested %d connections to socket. It takes %f seconds" % (N,t2-t1))
