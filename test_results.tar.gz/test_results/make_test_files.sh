#!/bin/bash

if [[ -d /etc/apache2/mods-available && -e /etc/apache2/mods-available ]]
then
touch /etc/apache2/mods-available/websocket.load
touch /etc/apache2/mods-available/websocket_draft76.load
touch /etc/apache2/mods-available/websocket.conf
touch /etc/apache2/mods-available/websocket_draft76.conf
echo "LoadModule websocket_module /usr/lib/apache2/modules/mod_websocket.so" >/etc/apache2/mods-available/websocket.load
echo "LoadModule websocket_module /usr/lib/apache2/modules/mod_websocket_draft76.so" >/etc/apache2/mods-available/websocket_draft76.load
echo "<IfModule mod_websocket.c>" >/etc/apache2/mods-available/websocket.conf
echo "  <Location /echo>" >>/etc/apache2/mods-available/websocket.conf
echo "    SetHandler websocket-handler" >>/etc/apache2/mods-available/websocket.conf
echo "    WebSocketHandler /usr/lib/apache2/modules/mod_websocket_echo.so echo_init" >>/etc/apache2/mods-available/websocket.conf
echo "  </Location>" >>/etc/apache2/mods-available/websocket.conf
echo "  <Location /dumb-increment>" >>/etc/apache2/mods-available/websocket.conf
echo "    SetHandler websocket-handler" >>/etc/apache2/mods-available/websocket.conf
echo "    WebSocketHandler /usr/lib/apache2/modules/mod_websocket_dumb_increment.so dumb_increment_init" >>/etc/apache2/mods-available/websocket.conf
echo "  </Location>" >>/etc/apache2/mods-available/websocket.conf
echo "</IfModule>" >>/etc/apache2/mods-available/websocket.conf
echo "<IfModule mod_websocket_draft76.c>" >/etc/apache2/mods-available/websocket_draft76.conf
echo "  <Location /echo>" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    SetHandler websocket-handler" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    WebSocketHandler /usr/lib/apache2/modules/mod_websocket_echo.so echo_init" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    SupportDraft75 On" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "  </Location>" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "  <Location /dumb-increment>" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    SetHandler websocket-handler" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    WebSocketHandler /usr/lib/apache2/modules/mod_websocket_dumb_increment.so dumb_increment_init" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "    SupportDraft75 On" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "  </Location>" >>/etc/apache2/mods-available/websocket_draft76.conf
echo "</IfModule>" >>/etc/apache2/mods-available/websocket_draft76.conf
else
echo "Something goes wrong. Directory /etc/apache2/mods-available do not exist"
exit
fi

if [[ -d /etc/apache2/mods-enabled && -e /etc/apache2/mods-enabled ]]
then
ln -s /etc/apache2/mods-available/websocket.load /etc/apache2/mods-enabled/websocket.load 
ln -s /etc/apache2/mods-available/websocket_draft76.load /etc/apache2/mods-enabled/websocket_draft76.load
ln -s /etc/apache2/mods-available/websocket.conf /etc/apache2/mods-enabled/websocket.conf
ln -s /etc/apache2/mods-available/websocket_draft76.conf /etc/apache2/mods-enabled/websocket_draft76.conf
else
echo "Something goes wrong. Directory /etc/apache2/mods-enabled do not exist"
fi

if [[ -d /var/www/html && -e /var/www/html ]]
then
cp ./examples/client.html /var/www/html/
cp ./examples/increment.html /var/www/html/
else
echo "Something goes wrong. Directory /var/www/html do not exist"
exit
fi

echo "All is done. You need restart your Apache web server to take effect changes"
